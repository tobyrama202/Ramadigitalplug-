
DROP POLICY IF EXISTS "anon update threads" ON public.chat_threads;
DROP POLICY IF EXISTS "anon delete threads" ON public.chat_threads;

CREATE OR REPLACE FUNCTION public.touch_thread() RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.chat_threads SET updated_at = now() WHERE id = NEW.thread_id;
  RETURN NEW;
END; $$;
