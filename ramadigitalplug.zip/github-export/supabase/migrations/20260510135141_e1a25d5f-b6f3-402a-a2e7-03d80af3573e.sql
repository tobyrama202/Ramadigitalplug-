
CREATE OR REPLACE FUNCTION public.touch_thread() RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
BEGIN
  UPDATE public.chat_threads SET updated_at = now() WHERE id = NEW.thread_id;
  RETURN NEW;
END; $$;
REVOKE EXECUTE ON FUNCTION public.touch_thread() FROM PUBLIC, anon, authenticated;

DROP POLICY IF EXISTS "anon insert threads" ON public.chat_threads;
DROP POLICY IF EXISTS "anon insert messages" ON public.chat_messages;
DROP POLICY IF EXISTS "anon insert inquiry" ON public.inquiries;

CREATE POLICY "insert threads with token" ON public.chat_threads
  FOR INSERT TO anon, authenticated
  WITH CHECK (visitor_token IS NOT NULL);

CREATE POLICY "insert messages with token" ON public.chat_messages
  FOR INSERT TO anon, authenticated
  WITH CHECK (visitor_token IS NOT NULL AND thread_id IS NOT NULL);

CREATE POLICY "insert inquiry with service" ON public.inquiries
  FOR INSERT TO anon, authenticated
  WITH CHECK (service IS NOT NULL AND length(summary) > 0);
