
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'inquiry-uploads',
  'inquiry-uploads',
  true,
  26214400, -- 25 MB
  ARRAY[
    'image/jpeg','image/png','image/webp','image/svg+xml','image/gif',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain',
    'video/mp4','video/quicktime',
    'audio/mpeg','audio/wav','audio/webm','audio/mp4','audio/ogg',
    'application/zip','application/x-zip-compressed','application/x-rar-compressed','application/vnd.rar'
  ]
)
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

CREATE POLICY "Public read inquiry uploads"
ON storage.objects FOR SELECT
USING (bucket_id = 'inquiry-uploads');

CREATE POLICY "Anyone can upload inquiry files"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'inquiry-uploads');
