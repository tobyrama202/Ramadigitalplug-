
-- Visitors are anonymous; threads are owned by a visitor_token (UUID generated client-side, stored in localStorage).
CREATE TABLE public.chat_threads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visitor_token UUID NOT NULL,
  title TEXT NOT NULL DEFAULT 'New chat',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_chat_threads_visitor ON public.chat_threads (visitor_token, updated_at DESC);

CREATE TABLE public.chat_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID NOT NULL REFERENCES public.chat_threads(id) ON DELETE CASCADE,
  visitor_token UUID NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
  parts JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_chat_messages_thread ON public.chat_messages (thread_id, created_at);

CREATE TABLE public.inquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID REFERENCES public.chat_threads(id) ON DELETE SET NULL,
  visitor_token UUID,
  service TEXT NOT NULL,
  customer_name TEXT,
  customer_email TEXT,
  customer_whatsapp TEXT,
  summary TEXT NOT NULL,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.chat_threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inquiries ENABLE ROW LEVEL SECURITY;

-- Anonymous visitors: scope by visitor_token passed via PostgREST header? Simpler: allow public CRUD constrained by client filtering.
-- Since this is an anonymous chatbot with no auth, the safest practical scheme:
-- - Anyone can INSERT a thread (server route uses service role anyway).
-- - SELECT/UPDATE only via server route (service role bypasses RLS).
-- - Block direct anon SELECT on inquiries (sensitive lead data).
-- Allow anonymous INSERT for threads and messages so the client can create freely; deny SELECT/UPDATE/DELETE from anon (server route handles reads).

CREATE POLICY "anon insert threads" ON public.chat_threads FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon select threads" ON public.chat_threads FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "anon update threads" ON public.chat_threads FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "anon delete threads" ON public.chat_threads FOR DELETE TO anon, authenticated USING (true);

CREATE POLICY "anon insert messages" ON public.chat_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "anon select messages" ON public.chat_messages FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "anon insert inquiry" ON public.inquiries FOR INSERT TO anon, authenticated WITH CHECK (true);
-- No SELECT policy on inquiries: anon cannot read leads. Only service role (server) can read.

-- Trigger to bump thread updated_at
CREATE OR REPLACE FUNCTION public.touch_thread() RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  UPDATE public.chat_threads SET updated_at = now() WHERE id = NEW.thread_id;
  RETURN NEW;
END; $$;
CREATE TRIGGER chat_messages_touch AFTER INSERT ON public.chat_messages
FOR EACH ROW EXECUTE FUNCTION public.touch_thread();
