import { useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";

const SECRET = "ADMINPAGE042811";

export function AdminSecretListener() {
  const navigate = useNavigate();

  useEffect(() => {
    let buffer = "";
    function onKey(e: KeyboardEvent) {
      if (e.key.length !== 1) return;
      buffer = (buffer + e.key).slice(-SECRET.length);
      if (buffer === SECRET) {
        buffer = "";
        sessionStorage.setItem("rama_admin_ok", "1");
        navigate({ to: "/admin" });
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);

  return null;
}
