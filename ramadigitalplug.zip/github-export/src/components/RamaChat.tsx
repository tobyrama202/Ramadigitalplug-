import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import {
  Send,
  Phone,
  Mail,
  ExternalLink,
  Sun,
  Moon,
  Sparkles,
  RotateCcw,
  MapPin,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useTheme } from "@/lib/theme";
import { useSiteSettings } from "@/hooks/useSiteSettings";
import type { SiteSettings } from "@/lib/site-settings";
import defaultLogo from "@/assets/rama-logo.png";

function getVisitorToken(): string {
  if (typeof window === "undefined") return "";
  let t = localStorage.getItem("rama_visitor_token");
  if (!t) {
    t = crypto.randomUUID();
    localStorage.setItem("rama_visitor_token", t);
  }
  return t;
}

export default function RamaChat() {
  const { settings } = useSiteSettings();
  const [visitorToken, setVisitorToken] = useState("");
  const [activeId, setActiveId] = useState<string | null>(null);
  const [initialMessages, setInitialMessages] = useState<UIMessage[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const t = getVisitorToken();
    setVisitorToken(t);
    (async () => {
      const { data } = await supabase
        .from("chat_threads")
        .select("id,title,updated_at")
        .eq("visitor_token", t)
        .order("updated_at", { ascending: false })
        .limit(1);
      const existing = (data ?? [])[0];
      if (existing) {
        setActiveId(existing.id);
      } else {
        const { data: created } = await supabase
          .from("chat_threads")
          .insert({ visitor_token: t, title: "New chat" })
          .select("id")
          .single();
        if (created) setActiveId(created.id);
      }
      setHydrated(true);
    })();
  }, []);

  useEffect(() => {
    if (!activeId) return;
    (async () => {
      const { data } = await supabase
        .from("chat_messages")
        .select("id,role,parts,created_at")
        .eq("thread_id", activeId)
        .order("created_at", { ascending: true });
      setInitialMessages(
        (data ?? []).map((r: any) => ({
          id: r.id,
          role: r.role,
          parts: Array.isArray(r.parts) ? r.parts : [],
        })),
      );
    })();
  }, [activeId]);

  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        body: () => ({ threadId: activeId, visitorToken }),
      }),
    [activeId, visitorToken],
  );

  async function newChat() {
    const { data } = await supabase
      .from("chat_threads")
      .insert({ visitor_token: visitorToken, title: "New chat" })
      .select("id")
      .single();
    if (data) {
      setInitialMessages([]);
      setActiveId(data.id);
    }
  }

  const logoSrc = settings.brand.logoUrl || defaultLogo;

  return (
    <div className="min-h-svh bg-background text-foreground" style={{ backgroundImage: "var(--gradient-hero)" }}>
      <SiteHeader settings={settings} logoSrc={logoSrc} />

      <main>
        {settings.hero.enabled && <Hero settings={settings} />}
        {settings.services.enabled && <Services settings={settings} />}

        <section id="chat" className="mx-auto w-full max-w-4xl px-4 pb-16">
          <div className="mb-5 text-center">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">{settings.chat.heading}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{settings.chat.subheading}</p>
          </div>

          <div className="overflow-hidden rounded-3xl border border-border bg-card/70 shadow-[var(--shadow-card)] backdrop-blur">
            {hydrated && activeId ? (
              <ChatPane
                key={activeId}
                settings={settings}
                logoSrc={logoSrc}
                transport={transport}
                initialMessages={initialMessages}
                onNewChat={newChat}
              />
            ) : (
              <div className="flex h-[420px] items-center justify-center text-sm text-muted-foreground">
                Loading assistant…
              </div>
            )}
          </div>
        </section>
      </main>

      {settings.footer.enabled && <SiteFooter settings={settings} />}
    </div>
  );
}

function SiteHeader({ settings, logoSrc }: { settings: SiteSettings; logoSrc: string }) {
  const { mode, toggle } = useTheme();
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-[var(--surface-blur)] backdrop-blur-xl">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-3">
        <a href="#top" className="flex min-w-0 items-center gap-3">
          {settings.brand.showLogo && (
            <img src={logoSrc} alt={settings.brand.name} className="h-9 w-9 rounded-xl object-contain" />
          )}
          <div className="min-w-0 leading-tight">
            <div className="truncate text-sm font-semibold sm:text-base">{settings.brand.name}</div>
            <div className="truncate text-[11px] text-muted-foreground">{settings.brand.tagline}</div>
          </div>
        </a>

        <div className="flex items-center gap-2">
          {settings.hero.showPortfolioButton && (
            <a
              href={settings.hero.portfolioUrl}
              target="_blank"
              rel="noreferrer"
              className="hidden items-center gap-1.5 rounded-full border border-border bg-card/70 px-3.5 py-2 text-xs font-medium transition hover:bg-accent sm:inline-flex"
            >
              CEO Portfolio <ExternalLink className="h-3 w-3" />
            </a>
          )}
          {settings.contact.showWhatsappButton && (
            <a
              href={`https://wa.me/${settings.contact.whatsappNumber}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold text-primary-foreground shadow-[var(--shadow-glow)] transition hover:opacity-90"
              style={{ backgroundImage: "var(--gradient-brand)" }}
            >
              <Phone className="h-3.5 w-3.5" /> WhatsApp
            </a>
          )}
          {settings.theme.allowToggle && (
            <button
              onClick={toggle}
              aria-label="Toggle theme"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-card/70 text-muted-foreground transition hover:bg-accent hover:text-foreground"
            >
              {mode === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
          )}
        </div>
      </div>
    </header>
  );
}

function Hero({ settings }: { settings: SiteSettings }) {
  return (
    <section id="top" className="mx-auto w-full max-w-6xl px-4 pb-12 pt-14 sm:pt-20">
      <div className="mx-auto max-w-3xl text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
          <Sparkles className="h-3 w-3 text-primary" /> {settings.hero.eyebrow}
        </span>
        <h1 className="mt-5 text-balance bg-clip-text text-4xl font-extrabold leading-tight tracking-tight text-transparent sm:text-5xl" style={{ backgroundImage: "var(--gradient-brand)" }}>
          {settings.hero.heading}
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-pretty text-sm text-muted-foreground sm:text-base">
          {settings.hero.subheading}
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
          <a
            href="#chat"
            className="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] transition hover:opacity-90"
            style={{ backgroundImage: "var(--gradient-brand)" }}
          >
            {settings.hero.primaryCtaLabel}
          </a>
          {settings.hero.showPortfolioButton && (
            <a
              href={settings.hero.portfolioUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-5 py-2.5 text-sm font-medium transition hover:bg-accent"
            >
              {settings.hero.secondaryCtaLabel} <ExternalLink className="h-3.5 w-3.5" />
            </a>
          )}
        </div>
      </div>
    </section>
  );
}

function Services({ settings }: { settings: SiteSettings }) {
  const items = settings.services.items.filter((s) => s.enabled);
  if (!items.length) return null;
  return (
    <section className="mx-auto w-full max-w-6xl px-4 pb-14">
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">{settings.services.heading}</h2>
        <p className="mt-2 text-sm text-muted-foreground">{settings.services.subheading}</p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((s) => (
          <a
            key={s.id}
            href="#chat"
            className="group rounded-2xl border border-border bg-card/70 p-5 shadow-[var(--shadow-card)] backdrop-blur transition hover:-translate-y-0.5 hover:border-primary/50"
          >
            <div className="text-2xl">{s.emoji}</div>
            <div className="mt-3 text-sm font-semibold">{s.title}</div>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{s.description}</p>
          </a>
        ))}
      </div>
    </section>
  );
}

function SiteFooter({ settings }: { settings: SiteSettings }) {
  return (
    <footer className="border-t border-border bg-card/50 backdrop-blur">
      <div className="mx-auto flex w-full max-w-6xl flex-col items-center gap-4 px-4 py-8 text-center text-xs text-muted-foreground sm:flex-row sm:justify-between sm:text-left">
        <div>{settings.footer.text}</div>
        <div className="flex flex-wrap items-center justify-center gap-4">
          <span className="inline-flex items-center gap-1.5"><Phone className="h-3 w-3" /> {settings.contact.whatsappLabel}</span>
          <span className="inline-flex items-center gap-1.5"><Mail className="h-3 w-3" /> {settings.contact.email}</span>
          {settings.contact.location && (
            <span className="inline-flex items-center gap-1.5"><MapPin className="h-3 w-3" /> {settings.contact.location}</span>
          )}
        </div>
        <div className="flex flex-wrap items-center justify-center gap-4">
          {settings.footer.links.map((l) => (
            <a key={l.label} href={l.url} target="_blank" rel="noreferrer" className="hover:text-foreground">
              {l.label}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
}

function ChatPane(props: {
  settings: SiteSettings;
  logoSrc: string;
  transport: DefaultChatTransport<UIMessage>;
  initialMessages: UIMessage[];
  onNewChat: () => void;
}) {
  const { settings } = props;
  const { messages, sendMessage, status } = useChat({
    messages: props.initialMessages,
    transport: props.transport,
  });
  const [input, setInput] = useState("");
  const taRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const isLoading = status === "submitted" || status === "streaming";

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, isLoading]);

  function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || isLoading) return;
    sendMessage({ text: trimmed });
    setInput("");
  }

  return (
    <div className="flex h-[600px] max-h-[80svh] flex-col">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div className="flex items-center gap-3">
          <img src={props.logoSrc} alt="" className="h-8 w-8 rounded-lg object-contain" />
          <div className="leading-tight">
            <div className="text-sm font-semibold">{settings.chat.assistantName}</div>
            <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-primary" />
              {settings.chat.statusText}
            </div>
          </div>
        </div>
        <button
          onClick={props.onNewChat}
          className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/70 px-3 py-1.5 text-[11px] font-medium text-muted-foreground transition hover:bg-accent hover:text-foreground"
        >
          <RotateCcw className="h-3 w-3" /> New chat
        </button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-5">
        <div className="mx-auto flex max-w-2xl flex-col gap-5">
          {messages.length === 0 && (
            <div className="flex flex-col items-center gap-5 py-6 text-center">
              <img src={props.logoSrc} alt="" className="h-14 w-14 rounded-2xl object-contain shadow-[var(--shadow-glow)]" />
              <div>
                <div className="text-lg font-semibold">{settings.chat.welcomeTitle}</div>
                <p className="mt-1 text-sm text-muted-foreground">{settings.chat.welcomeText}</p>
              </div>
              <div className="grid w-full gap-2 sm:grid-cols-2">
                {settings.chat.quickReplies.map((q) => (
                  <button
                    key={q}
                    onClick={() => send(q)}
                    className="rounded-xl border border-border bg-card/70 px-4 py-2.5 text-left text-sm transition hover:border-primary/60 hover:bg-accent"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m) => (
            <MessageBubble
              key={m.id}
              message={m}
              logoSrc={props.logoSrc}
              allMessages={messages}
              whatsappNumber={settings.contact.whatsappNumber}
            />
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="inline-block h-2 w-2 animate-pulse rounded-full bg-primary" />
              {settings.chat.assistantName} is thinking…
            </div>
          )}
        </div>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="flex items-end gap-2 border-t border-border px-4 py-3"
      >
        <textarea
          ref={taRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send(input);
            }
          }}
          rows={1}
          placeholder={settings.chat.placeholder}
          className="min-h-11 max-h-40 flex-1 resize-none rounded-xl border border-border bg-input px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
        <Button
          type="submit"
          size="icon"
          disabled={isLoading || !input.trim()}
          className="h-11 w-11 shrink-0 rounded-xl text-primary-foreground shadow-[var(--shadow-glow)]"
          style={{ backgroundImage: "var(--gradient-brand)" }}
        >
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}

function MessageBubble({
  message,
  logoSrc,
  allMessages,
  whatsappNumber,
}: {
  message: UIMessage;
  logoSrc: string;
  allMessages: UIMessage[];
  whatsappNumber: string;
}) {
  const isUser = message.role === "user";
  const text = (message.parts as any[])
    .filter((p) => p.type === "text")
    .map((p) => p.text)
    .join("");

  const inquiryId = useMemo(() => {
    for (let i = allMessages.length - 1; i >= 0; i--) {
      for (const p of allMessages[i].parts as any[]) {
        if (p.type?.startsWith("tool-") && p.output?.ok && p.output?.inquiry_id) {
          return p.output.inquiry_id as string;
        }
      }
    }
    return null;
  }, [allMessages]);

  if (isUser) {
    return (
      <div className="flex justify-end">
        <div
          className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-br-sm px-4 py-2.5 text-sm text-primary-foreground shadow-[var(--shadow-card)]"
          style={{ backgroundImage: "var(--gradient-brand)" }}
        >
          {text}
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-3">
      <img src={logoSrc} alt="" className="mt-1 h-7 w-7 shrink-0 rounded-md object-contain" />
      <div className={cn("prose prose-sm max-w-none text-foreground dark:prose-invert")}>
        <ReactMarkdown
          components={{
            a: ({ href, children, ...rest }) => {
              if (href === "#send-whatsapp") {
                return (
                  <WhatsAppCTA inquiryId={inquiryId} allMessages={allMessages} whatsappNumber={whatsappNumber} />
                );
              }
              return (
                <a href={href} target="_blank" rel="noreferrer" className="text-primary underline" {...rest}>
                  {children}
                </a>
              );
            },
          }}
        >
          {text}
        </ReactMarkdown>
        {(message.parts as any[]).some((p) => p.type?.startsWith("tool-") && p.output?.ok) &&
          !text.includes("#send-whatsapp") && (
            <div className="mt-3">
              <WhatsAppCTA inquiryId={inquiryId} allMessages={allMessages} whatsappNumber={whatsappNumber} />
            </div>
          )}
      </div>
    </div>
  );
}

function WhatsAppCTA({
  inquiryId,
  allMessages,
  whatsappNumber,
}: {
  inquiryId: string | null;
  allMessages: UIMessage[];
  whatsappNumber: string;
}) {
  const [busy, setBusy] = useState(false);
  return (
    <button
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        let data: any = null;
        if (inquiryId) {
          const res = await supabase
            .from("inquiries")
            .select("service,summary,customer_name,customer_email,customer_whatsapp,details,created_at")
            .eq("id", inquiryId)
            .maybeSingle();
          data = res.data;
        }
        const d: Record<string, any> = (data?.details as any) ?? {};
        const v = (x: any) => (x === undefined || x === null || x === "" ? "N/A" : String(x));
        const submitted = data?.created_at
          ? new Date(data.created_at).toLocaleString()
          : new Date().toLocaleString();

        const transcript: string[] = [];
        for (const m of allMessages) {
          const t = (m.parts as any[])
            .filter((p) => p.type === "text")
            .map((p) => p.text)
            .join("")
            .trim();
          if (!t) continue;
          transcript.push(m.role === "user" ? `👤 Client: ${t}` : `🤖 RamaBot: ${t}`);
          transcript.push("");
        }

        const lines = [
          "📩 NEW CLIENT INQUIRY — RAMADIGITALPLUG",
          "",
          "👤 CUSTOMER DETAILS",
          `Name: ${v(data?.customer_name)}`,
          `WhatsApp: ${v(data?.customer_whatsapp)}`,
          `Email: ${v(data?.customer_email)}`,
          "",
          "🛠 SELECTED SERVICE",
          v(data?.service),
          "",
          "📌 PROJECT INFORMATION",
          `Business Type: ${v(d.business_type)}`,
          `Project Type: ${v(d.project_type)}`,
          `Preferred Style: ${v(d.style)}`,
          `Number of Pages: ${v(d.pages)}`,
          `Features Needed: ${v(d.features)}`,
          `Budget: ${v(d.budget)}`,
          `Deadline: ${v(d.deadline)}`,
          `Delivery Location: ${v(d.delivery_location)}`,
          "",
          "📝 CLIENT REQUEST",
          v(d.custom_request ?? data?.summary),
          "",
          "📅 DATE SUBMITTED",
          submitted,
          "",
          "━━━━━━━━━━━━━━━━━━━━",
          "💬 FULL CHAT TRANSCRIPT",
          "━━━━━━━━━━━━━━━━━━━━",
          "",
          ...transcript,
        ];
        window.open(`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(lines.join("\n"))}`, "_blank");
        setBusy(false);
      }}
      className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium text-primary-foreground shadow-[var(--shadow-glow)] transition hover:opacity-90 disabled:opacity-60"
      style={{ backgroundImage: "var(--gradient-brand)" }}
    >
      📲 Send to WhatsApp now
    </button>
  );
}
