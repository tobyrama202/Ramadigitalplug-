import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { DEFAULT_SETTINGS, mergeSettings, type SiteSettings } from "@/lib/site-settings";

export function useSiteSettings() {
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("site_settings")
        .select("data")
        .eq("id", "default")
        .maybeSingle();
      if (cancelled) return;
      setSettings(mergeSettings(data?.data));
      setLoaded(true);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return { settings, loaded, setSettings };
}
