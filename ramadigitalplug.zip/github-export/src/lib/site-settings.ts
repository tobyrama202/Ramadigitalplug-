export type ServiceItem = {
  id: string;
  emoji: string;
  title: string;
  description: string;
  enabled: boolean;
};

export type SiteSettings = {
  brand: {
    name: string;
    tagline: string;
    logoUrl: string;
    showLogo: boolean;
  };
  hero: {
    enabled: boolean;
    eyebrow: string;
    heading: string;
    subheading: string;
    primaryCtaLabel: string;
    secondaryCtaLabel: string;
    portfolioUrl: string;
    showPortfolioButton: boolean;
  };
  services: {
    enabled: boolean;
    heading: string;
    subheading: string;
    items: ServiceItem[];
  };
  chat: {
    heading: string;
    subheading: string;
    placeholder: string;
    assistantName: string;
    statusText: string;
    welcomeTitle: string;
    welcomeText: string;
    quickReplies: string[];
  };
  contact: {
    whatsappNumber: string;
    whatsappLabel: string;
    email: string;
    location: string;
    showWhatsappButton: boolean;
  };
  footer: {
    enabled: boolean;
    text: string;
    links: { label: string; url: string }[];
  };
  seo: {
    title: string;
    description: string;
    ogTitle: string;
    ogDescription: string;
  };
  theme: {
    defaultMode: "light" | "dark";
    allowToggle: boolean;
    accent: string;
  };
  ai: {
    personaOverride: string;
  };
};

export const DEFAULT_SETTINGS: SiteSettings = {
  brand: {
    name: "Ramadigitalplug",
    tagline: "AI Business Assistant",
    logoUrl: "",
    showLogo: true,
  },
  hero: {
    enabled: true,
    eyebrow: "Premium Digital Solutions",
    heading: "Grow your brand with Ramadigitalplug",
    subheading:
      "Websites, branding, graphic design, printing, social media promotion and crypto support — powered by an intelligent assistant that understands your project.",
    primaryCtaLabel: "Start a project",
    secondaryCtaLabel: "CEO Portfolio",
    portfolioUrl: "https://ramadigitalplug-growth-hub.lovable.app/",
    showPortfolioButton: true,
  },
  services: {
    enabled: true,
    heading: "What we do",
    subheading: "Pick a service and the assistant will guide you through everything.",
    items: [
      { id: "web", emoji: "🖥️", title: "Website Development", description: "Business, portfolio, landing & e-commerce sites.", enabled: true },
      { id: "graphics", emoji: "🎨", title: "Flyer & Graphic Design", description: "Flyers, posters, banners & social media creatives.", enabled: true },
      { id: "brand", emoji: "✨", title: "Branding & Logo Design", description: "Logos, identity systems & brand guidelines.", enabled: true },
      { id: "print", emoji: "🖨️", title: "Printing Services", description: "Cards, stickers, customized nylon, posters & banners.", enabled: true },
      { id: "social", emoji: "📣", title: "Social Media Promotion", description: "Campaigns, growth & paid promotion.", enabled: true },
      { id: "crypto", emoji: "💱", title: "Crypto Exchange Assistance", description: "Safe, guided crypto exchange support.", enabled: true },
    ],
  },
  chat: {
    heading: "Talk to the assistant",
    subheading: "Describe your project and get a tailored plan in minutes.",
    placeholder: "Describe your project…",
    assistantName: "RamaBot",
    statusText: "online",
    welcomeTitle: "Welcome to Ramadigitalplug 👋",
    welcomeText: "Choose a service below or tell me what you need — I'll handle the rest.",
    quickReplies: [
      "Website Development",
      "Flyer & Graphic Design",
      "Branding & Logo Design",
      "Printing Services",
      "Social Media Promotion",
      "Crypto Exchange Assistance",
      "Pricing & Packages",
      "Book Consultation",
    ],
  },
  contact: {
    whatsappNumber: "2347019125700",
    whatsappLabel: "+234 701 912 5700",
    email: "ramadigitalplug@gmail.com",
    location: "Nigeria",
    showWhatsappButton: true,
  },
  footer: {
    enabled: true,
    text: "© Ramadigitalplug. Premium digital solutions.",
    links: [
      { label: "CEO Portfolio", url: "https://ramadigitalplug-growth-hub.lovable.app/" },
      { label: "WhatsApp", url: "https://wa.me/2347019125700" },
    ],
  },
  seo: {
    title: "Ramadigitalplug — AI Business Assistant",
    description:
      "Premium websites, branding, graphic design, printing, social promotion & crypto support. Chat with the Ramadigitalplug AI assistant.",
    ogTitle: "Ramadigitalplug — AI Business Assistant",
    ogDescription: "Premium AI assistant for digital services, branding & promotion.",
  },
  theme: {
    defaultMode: "dark",
    allowToggle: true,
    accent: "#3B82F6",
  },
  ai: {
    personaOverride: "",
  },
};

function isObj(v: unknown): v is Record<string, any> {
  return !!v && typeof v === "object" && !Array.isArray(v);
}

export function mergeSettings(raw: unknown): SiteSettings {
  const out: any = structuredClone(DEFAULT_SETTINGS);
  if (!isObj(raw)) return out;
  for (const key of Object.keys(out)) {
    const incoming = (raw as any)[key];
    if (!isObj(incoming)) continue;
    out[key] = { ...out[key], ...incoming };
  }
  return out as SiteSettings;
}
