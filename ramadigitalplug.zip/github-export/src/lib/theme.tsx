import { createContext, useCallback, useContext, useEffect, useState } from "react";

type Mode = "light" | "dark";

const ThemeCtx = createContext<{ mode: Mode; toggle: () => void; setMode: (m: Mode) => void }>({
  mode: "dark",
  toggle: () => {},
  setMode: () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setModeState] = useState<Mode>("dark");

  useEffect(() => {
    const stored = localStorage.getItem("rama_theme") as Mode | null;
    const initial: Mode = stored ?? "dark";
    setModeState(initial);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", mode === "dark");
    root.classList.toggle("light", mode === "light");
    root.style.colorScheme = mode;
  }, [mode]);

  const setMode = useCallback((m: Mode) => {
    setModeState(m);
    localStorage.setItem("rama_theme", m);
  }, []);

  const toggle = useCallback(() => {
    setModeState((prev) => {
      const next = prev === "dark" ? "light" : "dark";
      localStorage.setItem("rama_theme", next);
      return next;
    });
  }, []);

  return <ThemeCtx.Provider value={{ mode, toggle, setMode }}>{children}</ThemeCtx.Provider>;
}

export const useTheme = () => useContext(ThemeCtx);
