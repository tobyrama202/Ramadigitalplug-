import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const pinSchema = z.object({ pin: z.string().min(4).max(32) });
const saveSchema = z.object({ pin: z.string().min(4).max(32), data: z.any() });

export const verifyAdminPin = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => pinSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin
      .from("admin_config")
      .select("pin")
      .eq("id", "default")
      .maybeSingle();
    return { ok: !!row && row.pin === data.pin };
  });

export const saveSiteSettings = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => saveSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin
      .from("admin_config")
      .select("pin")
      .eq("id", "default")
      .maybeSingle();
    if (!row || row.pin !== data.pin) return { ok: false as const, error: "Invalid PIN" };

    const { error } = await supabaseAdmin
      .from("site_settings")
      .upsert({ id: "default", data: data.data as any });
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });

export const changeAdminPin = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({ pin: z.string().min(4).max(32), newPin: z.string().min(4).max(32) }).parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin
      .from("admin_config")
      .select("pin")
      .eq("id", "default")
      .maybeSingle();
    if (!row || row.pin !== data.pin) return { ok: false as const, error: "Invalid PIN" };
    const { error } = await supabaseAdmin
      .from("admin_config")
      .update({ pin: data.newPin, updated_at: new Date().toISOString() })
      .eq("id", "default");
    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const };
  });
