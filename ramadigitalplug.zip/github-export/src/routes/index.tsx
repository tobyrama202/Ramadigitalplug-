import { createFileRoute } from "@tanstack/react-router";
import RamaChat from "@/components/RamaChat";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ramadigitalplug — AI Business Assistant" },
      {
        name: "description",
        content:
          "Premium AI chatbot for websites, branding, graphic design, printing, social promotion & crypto support. Chat with Ramadigitalplug.",
      },
      { property: "og:title", content: "Ramadigitalplug — AI Business Assistant" },
      {
        property: "og:description",
        content: "Premium AI chatbot for digital services, branding & promotion.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return <RamaChat />;
}
