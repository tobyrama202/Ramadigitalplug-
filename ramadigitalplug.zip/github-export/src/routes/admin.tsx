import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  Lock,
  Save,
  ArrowLeft,
  Plus,
  Trash2,
  Sun,
  Moon,
  Loader2,
  CheckCircle2,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useTheme } from "@/lib/theme";
import { DEFAULT_SETTINGS, mergeSettings, type SiteSettings } from "@/lib/site-settings";
import { verifyAdminPin, saveSiteSettings, changeAdminPin } from "@/lib/admin.functions";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Panel — Ramadigitalplug" },
      { name: "description", content: "Private control panel for managing the Ramadigitalplug site content." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Admin Panel — Ramadigitalplug" },
      { property: "og:description", content: "Private control panel for site content." },
    ],
  }),
  component: AdminPage,
});

const TABS = [
  { id: "brand", label: "Brand" },
  { id: "hero", label: "Hero" },
  { id: "services", label: "Services" },
  { id: "chat", label: "Chat" },
  { id: "contact", label: "Contact" },
  { id: "footer", label: "Footer" },
  { id: "seo", label: "SEO" },
  { id: "theme", label: "Theme" },
  { id: "security", label: "Security" },
] as const;

function AdminPage() {
  const [pin, setPin] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState("");
  const verify = useServerFn(verifyAdminPin);

  useEffect(() => {
    const stored = sessionStorage.getItem("rama_admin_pin");
    if (stored) {
      setPin(stored);
      setUnlocked(true);
    }
  }, []);

  async function submitPin(e: React.FormEvent) {
    e.preventDefault();
    setChecking(true);
    setError("");
    try {
      const res = await verify({ data: { pin } });
      if (res.ok) {
        sessionStorage.setItem("rama_admin_pin", pin);
        setUnlocked(true);
      } else {
        setError("Incorrect PIN");
      }
    } catch {
      setError("Something went wrong. Try again.");
    } finally {
      setChecking(false);
    }
  }

  if (!unlocked) {
    return (
      <div
        className="flex min-h-svh items-center justify-center bg-background px-4 text-foreground"
        style={{ backgroundImage: "var(--gradient-hero)" }}
      >
        <form
          onSubmit={submitPin}
          className="w-full max-w-sm rounded-3xl border border-border bg-card/80 p-8 shadow-[var(--shadow-card)] backdrop-blur"
        >
          <div
            className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl text-primary-foreground shadow-[var(--shadow-glow)]"
            style={{ backgroundImage: "var(--gradient-brand)" }}
          >
            <Lock className="h-5 w-5" />
          </div>
          <h1 className="mt-5 text-center text-lg font-semibold">Admin access</h1>
          <p className="mt-1 text-center text-xs text-muted-foreground">Enter your PIN to manage the site.</p>
          <input
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            type="password"
            inputMode="numeric"
            autoFocus
            placeholder="••••••"
            className="mt-6 w-full rounded-xl border border-border bg-input px-4 py-3 text-center text-lg tracking-[0.4em] text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
          {error && <div className="mt-3 text-center text-xs text-destructive">{error}</div>}
          <Button
            type="submit"
            disabled={checking || pin.length < 4}
            className="mt-5 w-full rounded-xl text-primary-foreground shadow-[var(--shadow-glow)]"
            style={{ backgroundImage: "var(--gradient-brand)" }}
          >
            {checking ? <Loader2 className="h-4 w-4 animate-spin" /> : "Unlock"}
          </Button>
          <Link to="/" className="mt-4 block text-center text-xs text-muted-foreground hover:text-foreground">
            ← Back to site
          </Link>
        </form>
      </div>
    );
  }

  return <AdminDashboard pin={pin} />;
}

function AdminDashboard({ pin }: { pin: string }) {
  const { mode, toggle } = useTheme();
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("brand");
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<string>("");
  const [error, setError] = useState("");
  const save = useServerFn(saveSiteSettings);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("site_settings").select("data").eq("id", "default").maybeSingle();
      setSettings(mergeSettings(data?.data));
      setLoaded(true);
    })();
  }, []);

  function patch<K extends keyof SiteSettings>(key: K, value: Partial<SiteSettings[K]>) {
    setSettings((prev) => ({ ...prev, [key]: { ...prev[key], ...value } }));
  }

  async function handleSave() {
    setSaving(true);
    setError("");
    try {
      const res = await save({ data: { pin, data: settings } });
      if (res.ok) setSavedAt(new Date().toLocaleTimeString());
      else setError(res.error ?? "Save failed");
    } catch {
      setError("Save failed. Try again.");
    } finally {
      setSaving(false);
    }
  }

  if (!loaded) {
    return (
      <div className="flex min-h-svh items-center justify-center bg-background text-muted-foreground">
        Loading settings…
      </div>
    );
  }

  return (
    <div className="min-h-svh bg-background text-foreground" style={{ backgroundImage: "var(--gradient-hero)" }}>
      <header className="sticky top-0 z-40 border-b border-border bg-[var(--surface-blur)] backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-5xl items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-3">
            <Link
              to="/"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-card/70 text-muted-foreground hover:text-foreground"
              aria-label="Back to site"
            >
              <ArrowLeft className="h-4 w-4" />
            </Link>
            <div className="leading-tight">
              <div className="text-sm font-semibold">Admin Panel</div>
              <div className="text-[11px] text-muted-foreground">Edit everything on your main page</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {savedAt && (
              <span className="hidden items-center gap-1.5 text-[11px] text-muted-foreground sm:inline-flex">
                <CheckCircle2 className="h-3 w-3 text-primary" /> Saved {savedAt}
              </span>
            )}
            <button
              onClick={toggle}
              aria-label="Toggle theme"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-border bg-card/70 text-muted-foreground hover:text-foreground"
            >
              {mode === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <Button
              onClick={handleSave}
              disabled={saving}
              className="rounded-full text-primary-foreground shadow-[var(--shadow-glow)]"
              style={{ backgroundImage: "var(--gradient-brand)" }}
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              <span className="ml-1.5">Save all</span>
            </Button>
          </div>
        </div>
        <div className="mx-auto flex w-full max-w-5xl gap-1 overflow-x-auto px-4 pb-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "whitespace-nowrap rounded-full px-3.5 py-1.5 text-xs font-medium transition",
                tab === t.id
                  ? "text-primary-foreground shadow-[var(--shadow-glow)]"
                  : "border border-border bg-card/70 text-muted-foreground hover:text-foreground",
              )}
              style={tab === t.id ? { backgroundImage: "var(--gradient-brand)" } : undefined}
            >
              {t.label}
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto w-full max-w-5xl px-4 py-8">
        {error && (
          <div className="mb-4 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
            {error}
          </div>
        )}

        {tab === "brand" && (
          <Card title="Brand" desc="Your logo, business name and tagline.">
            <Text label="Business name" value={settings.brand.name} onChange={(v) => patch("brand", { name: v })} />
            <Text label="Tagline" value={settings.brand.tagline} onChange={(v) => patch("brand", { tagline: v })} />
            <Text
              label="Logo image URL"
              placeholder="https://… (leave blank to use the default logo)"
              value={settings.brand.logoUrl}
              onChange={(v) => patch("brand", { logoUrl: v })}
            />
            <Toggle label="Show logo" checked={settings.brand.showLogo} onChange={(v) => patch("brand", { showLogo: v })} />
          </Card>
        )}

        {tab === "hero" && (
          <Card title="Hero section" desc="The first thing visitors see.">
            <Toggle label="Show hero section" checked={settings.hero.enabled} onChange={(v) => patch("hero", { enabled: v })} />
            <Text label="Eyebrow" value={settings.hero.eyebrow} onChange={(v) => patch("hero", { eyebrow: v })} />
            <Text label="Heading" value={settings.hero.heading} onChange={(v) => patch("hero", { heading: v })} />
            <Area label="Subheading" value={settings.hero.subheading} onChange={(v) => patch("hero", { subheading: v })} />
            <Text label="Primary button label" value={settings.hero.primaryCtaLabel} onChange={(v) => patch("hero", { primaryCtaLabel: v })} />
            <Text label="Portfolio button label" value={settings.hero.secondaryCtaLabel} onChange={(v) => patch("hero", { secondaryCtaLabel: v })} />
            <Text label="CEO portfolio URL" value={settings.hero.portfolioUrl} onChange={(v) => patch("hero", { portfolioUrl: v })} />
            <Toggle label="Show portfolio button" checked={settings.hero.showPortfolioButton} onChange={(v) => patch("hero", { showPortfolioButton: v })} />
          </Card>
        )}

        {tab === "services" && (
          <Card title="Services" desc="Cards shown on the main page.">
            <Toggle label="Show services section" checked={settings.services.enabled} onChange={(v) => patch("services", { enabled: v })} />
            <Text label="Section heading" value={settings.services.heading} onChange={(v) => patch("services", { heading: v })} />
            <Text label="Section subheading" value={settings.services.subheading} onChange={(v) => patch("services", { subheading: v })} />
            <div className="space-y-3">
              {settings.services.items.map((item, i) => (
                <div key={item.id} className="rounded-2xl border border-border bg-background/40 p-4">
                  <div className="grid gap-3 sm:grid-cols-[70px_1fr]">
                    <Text
                      label="Emoji"
                      value={item.emoji}
                      onChange={(v) =>
                        patch("services", {
                          items: settings.services.items.map((s, j) => (j === i ? { ...s, emoji: v } : s)),
                        })
                      }
                    />
                    <Text
                      label="Title"
                      value={item.title}
                      onChange={(v) =>
                        patch("services", {
                          items: settings.services.items.map((s, j) => (j === i ? { ...s, title: v } : s)),
                        })
                      }
                    />
                  </div>
                  <Area
                    label="Description"
                    value={item.description}
                    onChange={(v) =>
                      patch("services", {
                        items: settings.services.items.map((s, j) => (j === i ? { ...s, description: v } : s)),
                      })
                    }
                  />
                  <div className="mt-2 flex items-center justify-between">
                    <Toggle
                      label="Visible"
                      checked={item.enabled}
                      onChange={(v) =>
                        patch("services", {
                          items: settings.services.items.map((s, j) => (j === i ? { ...s, enabled: v } : s)),
                        })
                      }
                    />
                    <button
                      onClick={() =>
                        patch("services", { items: settings.services.items.filter((_, j) => j !== i) })
                      }
                      className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Remove
                    </button>
                  </div>
                </div>
              ))}
              <button
                onClick={() =>
                  patch("services", {
                    items: [
                      ...settings.services.items,
                      { id: crypto.randomUUID(), emoji: "⭐", title: "New service", description: "Describe this service.", enabled: true },
                    ],
                  })
                }
                className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/70 px-3.5 py-2 text-xs font-medium hover:bg-accent"
              >
                <Plus className="h-3.5 w-3.5" /> Add service
              </button>
            </div>
          </Card>
        )}

        {tab === "chat" && (
          <Card title="Chat assistant" desc="Text, greeting and quick replies of the assistant.">
            <Text label="Section heading" value={settings.chat.heading} onChange={(v) => patch("chat", { heading: v })} />
            <Text label="Section subheading" value={settings.chat.subheading} onChange={(v) => patch("chat", { subheading: v })} />
            <Text label="Assistant name" value={settings.chat.assistantName} onChange={(v) => patch("chat", { assistantName: v })} />
            <Text label="Status text" value={settings.chat.statusText} onChange={(v) => patch("chat", { statusText: v })} />
            <Text label="Input placeholder" value={settings.chat.placeholder} onChange={(v) => patch("chat", { placeholder: v })} />
            <Text label="Welcome title" value={settings.chat.welcomeTitle} onChange={(v) => patch("chat", { welcomeTitle: v })} />
            <Area label="Welcome text" value={settings.chat.welcomeText} onChange={(v) => patch("chat", { welcomeText: v })} />
            <Area
              label="Quick replies (one per line)"
              value={settings.chat.quickReplies.join("\n")}
              onChange={(v) => patch("chat", { quickReplies: v.split("\n").map((s) => s.trim()).filter(Boolean) })}
            />
          </Card>
        )}

        {tab === "contact" && (
          <Card title="Contact" desc="Where clients reach you.">
            <Text label="WhatsApp number (digits only)" value={settings.contact.whatsappNumber} onChange={(v) => patch("contact", { whatsappNumber: v.replace(/\D/g, "") })} />
            <Text label="WhatsApp display label" value={settings.contact.whatsappLabel} onChange={(v) => patch("contact", { whatsappLabel: v })} />
            <Text label="Email" value={settings.contact.email} onChange={(v) => patch("contact", { email: v })} />
            <Text label="Location" value={settings.contact.location} onChange={(v) => patch("contact", { location: v })} />
            <Toggle label="Show WhatsApp button in header" checked={settings.contact.showWhatsappButton} onChange={(v) => patch("contact", { showWhatsappButton: v })} />
          </Card>
        )}

        {tab === "footer" && (
          <Card title="Footer" desc="Bottom of the page.">
            <Toggle label="Show footer" checked={settings.footer.enabled} onChange={(v) => patch("footer", { enabled: v })} />
            <Text label="Footer text" value={settings.footer.text} onChange={(v) => patch("footer", { text: v })} />
            <div className="space-y-3">
              {settings.footer.links.map((l, i) => (
                <div key={i} className="grid gap-3 rounded-2xl border border-border bg-background/40 p-4 sm:grid-cols-2">
                  <Text
                    label="Label"
                    value={l.label}
                    onChange={(v) => patch("footer", { links: settings.footer.links.map((x, j) => (j === i ? { ...x, label: v } : x)) })}
                  />
                  <Text
                    label="URL"
                    value={l.url}
                    onChange={(v) => patch("footer", { links: settings.footer.links.map((x, j) => (j === i ? { ...x, url: v } : x)) })}
                  />
                  <button
                    onClick={() => patch("footer", { links: settings.footer.links.filter((_, j) => j !== i) })}
                    className="justify-self-start rounded-lg px-2.5 py-1.5 text-xs text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                  >
                    Remove link
                  </button>
                </div>
              ))}
              <button
                onClick={() => patch("footer", { links: [...settings.footer.links, { label: "New link", url: "https://" }] })}
                className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card/70 px-3.5 py-2 text-xs font-medium hover:bg-accent"
              >
                <Plus className="h-3.5 w-3.5" /> Add link
              </button>
            </div>
          </Card>
        )}

        {tab === "seo" && (
          <Card title="SEO & sharing" desc="How your page appears in search and social previews.">
            <Text label="Page title" value={settings.seo.title} onChange={(v) => patch("seo", { title: v })} />
            <Area label="Meta description" value={settings.seo.description} onChange={(v) => patch("seo", { description: v })} />
            <Text label="Social title" value={settings.seo.ogTitle} onChange={(v) => patch("seo", { ogTitle: v })} />
            <Area label="Social description" value={settings.seo.ogDescription} onChange={(v) => patch("seo", { ogDescription: v })} />
          </Card>
        )}

        {tab === "theme" && (
          <Card title="Theme" desc="Appearance defaults for visitors.">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Default mode</label>
              <div className="flex gap-2">
                {(["dark", "light"] as const).map((m) => (
                  <button
                    key={m}
                    onClick={() => patch("theme", { defaultMode: m })}
                    className={cn(
                      "rounded-full px-4 py-2 text-xs font-medium capitalize transition",
                      settings.theme.defaultMode === m
                        ? "text-primary-foreground shadow-[var(--shadow-glow)]"
                        : "border border-border bg-card/70 text-muted-foreground",
                    )}
                    style={settings.theme.defaultMode === m ? { backgroundImage: "var(--gradient-brand)" } : undefined}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>
            <Toggle label="Let visitors switch light/dark" checked={settings.theme.allowToggle} onChange={(v) => patch("theme", { allowToggle: v })} />
          </Card>
        )}

        {tab === "security" && <SecurityCard pin={pin} />}
      </main>
    </div>
  );
}

function SecurityCard({ pin }: { pin: string }) {
  const [newPin, setNewPin] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const change = useServerFn(changeAdminPin);

  return (
    <Card title="Security" desc="Change the PIN used to open this panel.">
      <Text label="New PIN (min 4 characters)" value={newPin} onChange={setNewPin} />
      {msg && <div className="text-xs text-muted-foreground">{msg}</div>}
      <Button
        disabled={busy || newPin.length < 4}
        onClick={async () => {
          setBusy(true);
          setMsg("");
          try {
            const res = await change({ data: { pin, newPin } });
            if (res.ok) {
              sessionStorage.setItem("rama_admin_pin", newPin);
              setMsg("PIN updated. Use the new PIN next time.");
              setNewPin("");
            } else setMsg(res.error ?? "Could not update PIN");
          } finally {
            setBusy(false);
          }
        }}
        className="w-fit rounded-xl text-primary-foreground shadow-[var(--shadow-glow)]"
        style={{ backgroundImage: "var(--gradient-brand)" }}
      >
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Update PIN"}
      </Button>
      <p className="text-xs text-muted-foreground">
        Tip: typing the secret phrase anywhere on the site opens this panel directly.
      </p>
    </Card>
  );
}

function Card({ title, desc, children }: { title: string; desc: string; children: React.ReactNode }) {
  return (
    <section className="rounded-3xl border border-border bg-card/70 p-6 shadow-[var(--shadow-card)] backdrop-blur">
      <h2 className="text-base font-semibold">{title}</h2>
      <p className="mt-1 text-xs text-muted-foreground">{desc}</p>
      <div className="mt-5 flex flex-col gap-4">{children}</div>
    </section>
  );
}

function Text({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</label>
      <input
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-border bg-input px-3.5 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
      />
    </div>
  );
}

function Area({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="mb-1.5 block text-xs font-medium text-muted-foreground">{label}</label>
      <textarea
        value={value}
        rows={3}
        onChange={(e) => onChange(e.target.value)}
        className="w-full resize-y rounded-xl border border-border bg-input px-3.5 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
      />
    </div>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex w-fit items-center gap-3 text-sm"
    >
      <span
        className={cn(
          "relative inline-flex h-5 w-9 items-center rounded-full transition",
          checked ? "bg-primary" : "bg-muted",
        )}
      >
        <span
          className={cn(
            "inline-block h-4 w-4 transform rounded-full bg-background transition",
            checked ? "translate-x-4" : "translate-x-0.5",
          )}
        />
      </span>
      <span className="text-muted-foreground">{label}</span>
    </button>
  );
}
