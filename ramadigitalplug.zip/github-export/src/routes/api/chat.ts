import "@tanstack/react-start";
import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, tool, stepCountIs, type UIMessage } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway";
import { RAMA_SYSTEM_PROMPT } from "@/lib/system-prompt";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

type Body = {
  messages?: UIMessage[];
  threadId?: string;
  visitorToken?: string;
};

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }: { request: Request }) => {
        const { messages, threadId, visitorToken } = (await request.json()) as Body;
        if (!Array.isArray(messages) || !threadId || !visitorToken) {
          return new Response("Bad request", { status: 400 });
        }
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const gateway = createLovableAiGatewayProvider(key);
        const model = gateway("google/gemini-3-flash-preview");

        const submitTool = tool({
          description:
            "Submit the completed customer inquiry once enough details are collected. Returns an inquiry id.",
          inputSchema: z.object({
            service: z.string().min(2).max(120),
            summary: z.string().min(20).max(4000),
            customer_name: z.string().min(2).max(120),
            customer_email: z.string().email().max(200),
            customer_whatsapp: z.string().min(7).max(40),
            details: z.object({
              business_type: z.string().min(1),
              project_type: z.string().min(1),
              style: z.string().min(1),
              pages: z.string().optional().default("N/A"),
              features: z.string().min(1),
              budget: z.string().min(1),
              deadline: z.string().min(1),
              delivery_location: z.string().optional().default("N/A"),
              uploaded_files: z.string().optional().default("None"),
              custom_request: z.string().min(1),
            }).passthrough(),
          }),
          execute: async (input) => {
            const { data, error } = await supabaseAdmin
              .from("inquiries")
              .insert({
                thread_id: threadId,
                visitor_token: visitorToken,
                service: input.service,
                summary: input.summary,
                customer_name: input.customer_name,
                customer_email: input.customer_email,
                customer_whatsapp: input.customer_whatsapp,
                details: (input.details ?? {}) as never,
              })
              .select("id")
              .single();
            if (error) {
              console.error("inquiry insert error", error);
              return { ok: false, error: error.message };
            }
            return { ok: true, inquiry_id: data.id };
          },
        });

        try {
          const result = streamText({
            model,
            system: RAMA_SYSTEM_PROMPT,
            messages: await convertToModelMessages(messages),
            tools: { submit_inquiry: submitTool },
            stopWhen: stepCountIs(50),
          });

          return result.toUIMessageStreamResponse({
            originalMessages: messages,
            onFinish: async ({ messages: finalMessages }) => {
              try {
                const last = finalMessages[finalMessages.length - 1];
                const userMsg = messages[messages.length - 1];
                if (userMsg) {
                  await supabaseAdmin.from("chat_messages").insert({
                    thread_id: threadId,
                    visitor_token: visitorToken,
                    role: userMsg.role,
                    parts: userMsg.parts as never,
                  });
                }
                if (last && last.role === "assistant") {
                  await supabaseAdmin.from("chat_messages").insert({
                    thread_id: threadId,
                    visitor_token: visitorToken,
                    role: "assistant",
                    parts: last.parts as never,
                  });
                }
              } catch (e) {
                console.error("persist messages error", e);
              }
            },
          });
        } catch (e) {
          console.error("chat error", e);
          return new Response(
            JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
            { status: 500, headers: { "Content-Type": "application/json" } },
          );
        }
      },
    },
  },
});
